<div class="content-wrapper">
    
<section class="content">
    <div class="box box-warning box-solid">
        <div class="box-header with-border">
            <h3 class="box-title">Tab_pricelist Read</h3>
        </div>
        
        
<table class='table table-bordered>'>
	    <tr><td>Kode Kasir</td><td><?php echo $kode_kasir; ?></td></tr>
	    <tr><td>Kode Barang</td><td><?php echo $kode_barang; ?></td></tr>
	    <tr><td>Qty A</td><td><?php echo $qty_a; ?></td></tr>
	    <tr><td>Qty B</td><td><?php echo $qty_b; ?></td></tr>
	    <tr><td>Harga</td><td><?php echo $harga; ?></td></tr>
	    <tr><td>Keterangan</td><td><?php echo $keterangan; ?></td></tr>
	    <!-- <tr><td>Opsi1</td><td><?php echo $opsi1; ?></td></tr>
	    <tr><td>Opsi2</td><td><?php echo $opsi2; ?></td></tr>
	    <tr><td>Opsi3</td><td><?php echo $opsi3; ?></td></tr>
	    <tr><td>Opsi4</td><td><?php echo $opsi4; ?></td></tr>
	    <tr><td>Opsi5</td><td><?php echo $opsi5; ?></td></tr> -->
	    <tr><td></td><td><a href="<?php echo site_url('tab_pricelist') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>

</div>
</div>
</div>