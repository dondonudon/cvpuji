<div class="content-wrapper">

<section class="content">
    <div class="box box-warning box-solid">
        <div class="box-header with-border">
            <h3 class="box-title">Tipe kasir Read</h3>
        </div>


<table class='table table-bordered>'>
	    <tr><td>Nama</td><td><?php echo $nama; ?></td></tr>
	    <tr><td>Keterangan</td><td><?php echo $keterangan; ?></td></tr>
	    <tr><td>QTY A</td><td><?php echo $qty_a; ?></td></tr>
	    <tr><td>QTY B</td><td><?php echo $qty_b; ?></td></tr>
	    <!-- <tr><td>Opsi3</td><td><?php echo $opsi3; ?></td></tr>
	    <tr><td>Opsi4</td><td><?php echo $opsi4; ?></td></tr>
	    <tr><td>Opsi5</td><td><?php echo $opsi5; ?></td></tr> -->
	    <tr><td></td><td><a href="<?php echo site_url('tab_kasir') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>

</div>
</div>
</div>