<div class="content-wrapper">
    
<section class="content">
    <div class="box box-warning box-solid">
        <div class="box-header with-border">
            <h3 class="box-title">Master_kasir Read</h3>
        </div>
        
        
<table class='table table-bordered>'>
	    <tr><td>Nama</td><td><?php echo $nama; ?></td></tr>
		<!-- <tr><td>Tipe Kasir</td><td><?php echo $nama_kasir; ?></td></tr> -->
	    <tr><td>Alamat</td><td><?php echo $alamat; ?></td></tr>
	    <tr><td>Kota</td><td><?php echo $kota; ?></td></tr>
	    <tr><td>Telp</td><td><?php echo $telp; ?></td></tr>
	    <tr><td>PIC</td><td><?php echo $PIC; ?></td></tr>
	    <tr><td>Url</td><td><?php echo $url; ?></td></tr>
	    <tr><td>Keterangan</td><td><?php echo $keterangan; ?></td></tr>
	    <!-- <tr><td>Opsi1</td><td><?php echo $opsi1; ?></td></tr>
	    <tr><td>Opsi2</td><td><?php echo $opsi2; ?></td></tr>
	    <tr><td>Opsi3</td><td><?php echo $opsi3; ?></td></tr>
	    <tr><td>Opsi4</td><td><?php echo $opsi4; ?></td></tr>
	    <tr><td>Opsi5</td><td><?php echo $opsi5; ?></td></tr> -->
	    <tr><td></td><td><a href="<?php echo site_url('master_kasir') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>

</div>
</div>
</div>